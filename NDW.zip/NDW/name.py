import copy
import os
import json
import argparse
import re
from collections import defaultdict

from mpmath import floor
from tqdm import tqdm
import concurrent.futures
from utils import call_large_model, parse_json_response, load_yaml_config, merge_similar_emotions_with_llm


def parse_txt_to_json(txt_content):
    """将txt格式内容解析为json格式"""
    dialogues = []
    lines = txt_content.strip().split('\n')
    
    for line in lines:
        # 匹配发言人行，格式如：发言人1 sentence_id:1 00:00
        speaker_match = re.match(r'(\S+)\s+sentence_id:(\d+)\s+(\d{2}:\d{2})', line)
        if speaker_match:
            holder = speaker_match.group(1)
            sentence_id = int(speaker_match.group(2))
            # 获取下一行作为句子内容
            sentence = ""
            # 查找下一个非空行作为句子内容
            for next_line in lines[lines.index(line)+1:]:
                if next_line.strip():
                    sentence = next_line.strip()
                    break
            
            dialogues.append({
                "holder": holder,
                "sentence_id": sentence_id,
                "input_sentence": sentence
            })
    
    return dialogues


def format_chat_history_for_llm(chat_data):
    formatted_chat = []

    for idx, item in enumerate(chat_data):
        holder = item.get("holder", "")
        sentence_id = item.get("sentence_id", "")
        sentence = item.get("input_sentence", "")
        if holder and sentence:
            formatted_chat.append(f'({sentence_id}) "{holder}": "{sentence}"')

    return "[\n" + ",\n".join(formatted_chat) + "\n]"


def segment_events_by_topic_with_sliding_window(dialogues, api_key, base_url, model_name, window_size=10, step_size=8):
    total_sentences = len(dialogues)
    print(f"共计{total_sentences}个句子，切分成{floor(total_sentences // step_size) + 1}个窗口进行滑动")
    event_pool = defaultdict(lambda: {"events": []})
    step_results = []
    for start in range(0, total_sentences, step_size):
        print(f"now start at {start} with {step_size}, all is {total_sentences}")
        window_data = dialogues[start : start + window_size]
        formatted_chat = format_chat_history_for_llm(window_data)

        event_pool_copy = copy.deepcopy(event_pool)
        for holder_data in event_pool_copy.values():
            for event in holder_data["events"]:
                event.pop("sentence_ids", None)

        history_formatted = json.dumps(event_pool_copy, ensure_ascii=False, indent=2)
        system_prompt = """
你是一名高级情绪事件分析助手。你的任务是：
1. **分析对话数据**，识别出 **关键情绪事件**（event）。
2. **合并相似事件**，避免重复创建多个 event。
3. **保证情绪演变的连贯性**，记录关键的情绪变化，而不是简单重复相同情绪。

### 数据特点 
1. 这是段对话历史包含多个说话人，语言非常口语化。由于我给你提供的窗口是滑动的二不是完整的历史记录，可能当前句子属于上一个句子的event，而仅仅是一个reason。这种时候你需要合并在一个历史事件中，而不是创建一个新的事件。
2. 可能存在某个角色连续多次发言的情况。
3. 五元组信息与历史对话顺序相同，可用于辅助识别角色的情绪波动。这个角色的情感五元组非常重要，这是描述了当下这句话Holder（说话人的情感).这是辅助你分析情绪事件的关键。
4. 当前人说话可能没有任何情绪或参与到任何事件，比如主持人活着旁白，这种时候，events允许是空的。

### 输入数据中历史记录和五元组的结构是：
历史记录:
[
    {"holder": "说话人1", "sentence": "说话内容1"}
    {"holder": "说话人2", "sentence": "说话内容2"}
    {"holder": "说话人1", "sentence": "说话内容3"}
    ...（多条记录）
]

### 输出格式要求

1. JSON 格式，外层结构应只包含当前角色的 ID，例如 `"1": { "events": [...] }`。
2. `events` 为一个列表，每个事件包含：
    - "event"（事件名称，通常是一个很大的事件或者一个场景，每个角色的两个话题差异通常是很大的）
    - "emotions"（角色在该事件中的情绪列表和每个阶段导致这个情绪的原因）

3. `emotions` 结构：
    - 只记录**关键的情绪变化**，避免相同情绪重复
    - `state` 选项：`["positive", "negative", "neutral", "ambiguous", "doubt"]`
    - `reason` 需要描述角色情绪变化的依据或原因。这通常是这个事件的进展，或者更换了话题，比如实验中的某个话题。
    
具体格式如下：
```json
{
    "角色ID_1": {
        "events": [
            {
                "event": 事件名称,
                "sentence_ids": 跟这个事件相关的句子编号，是一个列表，返回()中的数字，比如第一句，第二句，第五句，返回[1,2,5]
                "emotions": [
                    {
                        "source_id": 角色ID(只有一个, 一个数字)，如果这个情感变化是由于某一个角色（一定是角色ID）导致，则输出对应角色ID。如果没有指定，或者由于上下文理解为自己的情感变化，则为自己的角色ID。这个句子一定出现在所有的holders内。
                        "state": "positive/negative/neutral/ambiguous/doubt",
                        "reason": 该事件产生该情绪的原因
                    }
                ]
            }
        ]
    },
    "角色ID_2": {
        ... 相同的结构
    }
}
```

这是一个返回的例子:

```json
{
    "1": {
        "events": [
            {
                "event": "朋友拒绝分享食物",
                "sentence_ids": [0, 2, 5]
                "emotions": [
                    {
                        ”source_id": 3
                        "state": "negative",
                        "reason": "对方不愿意分享食物，让自己感到不开心"
                    },
                    {
                        ”source_id": 2
                        "state": "doubt",
                        "reason": "对方平时会吃这个，但今天却拒绝，感到困惑"
                    }
                ]
            }
        ]
    }
    "2": {
        "events": []
    }
}
```

在实际的场景中，”source_id"要根据上下文判断，3 和 2 仅仅是假设，实际句子中，角色ID(只有一个, 一个数字)，如果这个情感变化是由于某一个角色（一定是角色ID）导致，则输出对应角色ID。如果没有指定，或者由于上下文理解为自己的情感变化，则为自己的角色ID。这个句子一定出现在所有的holders内。

### 注意

- 不要遗漏任何关键字段，source_id 一定要在emotions中输出，这个字段不能省略。
- 同一事件中若情绪未发生变化，不应重复记录。必须根据事件主题，合并情绪变化的原因。
- 每个角色都必须有输出，如果没有明显的事件，需要输出空列表。这很重要。 同一个人在一个数据集中通常不会有太多event。你应该给出尽量少的event事件，具体的情感变化应该放在emotions字段中。
- event, reason 都应该简单，表达清晰。emotions中可以列出详细的情感变化。
- sentence_ids 不要输出句子，只要对应的()内的句子ID。没有"sentences"字段，不允许输出任何原始的句子!,只能输出"sentences_id"字段，这是针对这个事件的句子ID。
- 不需要带有任何解释,只能返回要求内的内容。输出格式必须完全和 ### 输出格式要求的一样。 返回的必须是一个dict而不是一个list结构的json，最外层必须是dict。
    
请直接返回 JSON，不能有多余解释。
""".strip()

        user_prompt = f"""
[之前已经检测到的事件]
{history_formatted}
- **请按照格式输出 JSON**，不要遗漏任何关键字段，source_id 一定要在emotions中输出，这个字段不能省略。
        """
        parsed_response = None
        for _ in range(3):
            response = call_large_model(
                messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}],
                api_key=api_key,
                base_url=base_url,
                model=model_name,
            )
            parsed_response = parse_json_response(response)
            if parsed_response and parsed_response != {}:
                break
        if not parsed_response:
            parsed_response = {}
        for holder, holder_data in parsed_response.items():
            if holder not in event_pool:
                event_pool[holder] = {"events": []}
            try:
                for new_event in holder_data["events"]:
                    existing_event = next(
                        (e for e in event_pool[holder]["events"] if e["event"] == new_event["event"]), None
                    )
                    if existing_event:
                        existing_event["emotions"].extend(new_event["emotions"])
                        existing_event["sentence_ids"].extend(new_event["sentence_ids"])
                    else:
                        event_pool[holder]["events"].append(new_event)
            except Exception as e:
                print(f"Error processing {holder} at {start} with {step_size}")
        print("enter in event_pool\n=======================\n")
        for holder_data in event_pool.values():
            for event in holder_data["events"]:
                event["sentence_ids"] = list(set(event["sentence_ids"]))
                event["sentences"] = [
                    next((item["input_sentence"] for item in dialogues if item.get("sentence_id") == idx), "") 
                    for idx in event["sentence_ids"]
                ]
        step_results.append({"step": start // step_size + 1, "events": parsed_response})
    for holder, holder_data in event_pool.items():
        for event in holder_data["events"]:
            optimized_emotions = merge_similar_emotions_with_llm(event["emotions"], api_key, base_url, model_name)
            event["emotions"] = optimized_emotions

    return event_pool, step_results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="outputs")
    parser.add_argument("--config_path", type=str, default="config.yaml")
    parser.add_argument("--llm_model", type=str, required=True)
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--window_sizes", type=str, default="20", help="滑动窗口大小，多个用逗号分隔，比如 '10,40'")
    parser.add_argument("--step_sizes", type=str, default="10", help="滑动步长，多个用逗号分隔，比如 '8,30'")
    args = parser.parse_args()
    window_sizes = list(map(int, args.window_sizes.split(",")))
    step_sizes = list(map(int, args.step_sizes.split(",")))

    if len(window_sizes) != len(step_sizes):
        raise ValueError("需要提供相同数量的滑动窗口和步长组合")

    llm_cfg = load_yaml_config(args.config_path, args.llm_model, "llm_config")
    os.makedirs(args.output_dir, exist_ok=True)
    # 修改为处理txt文件
    all_files = sorted([f for f in os.listdir(args.input_dir) if f.endswith(".txt")])

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.batch) as executor:
        with tqdm(total=len(all_files) * len(window_sizes) * len(step_sizes), desc="Processing files") as pbar:
            futures = {}

            for fname in all_files:
                file_path = os.path.join(args.input_dir, fname)
                # 读取txt文件内容
                with open(file_path, "r", encoding="utf-8") as f:
                    txt_content = f.read()
                # 解析txt为json格式
                dialogues = parse_txt_to_json(txt_content)

                for window_size, step_size in zip(window_sizes, step_sizes):
                    match = re.search(r"(\d+)", fname)
                    if match:
                        number = match.group(1)
                    else:
                        number = "unknown"
                    event_output_path = os.path.join(args.output_dir, f"output_emotions_{number}_events.json")
                    step_output_path = os.path.join(args.output_dir, f"output_emotions_{number}_steps.json")
                    if os.path.exists(event_output_path) and os.path.exists(step_output_path):
                        pbar.update(1)
                        print(f"Skipping {fname} with window_size={window_size}, step_size={step_size}")
                        continue

                    futures[
                        executor.submit(
                            segment_events_by_topic_with_sliding_window,
                            dialogues,
                            llm_cfg["api_key"],
                            llm_cfg["base_url"],
                            llm_cfg["model"],
                            window_size,
                            step_size,
                        )
                    ] = (fname, window_size, step_size)

            # Handle task results as they complete
            for future in concurrent.futures.as_completed(futures):
                fname, window_size, step_size = futures[future]
                event_pool, step_results = future.result()

                match = re.search(r"(\d+)", fname)
                if match:
                    number = match.group(1)
                else:
                    number = "unknown"

                output_file_path = os.path.join(args.output_dir, f"output_emotions_{number}_events.json")
                step_results_path = os.path.join(args.output_dir, f"output_emotions_{number}_steps.json")
                print(f"{output_file_path} is saved.")
                with open(output_file_path, "w", encoding="utf-8") as f:
                    json.dump(event_pool, f, ensure_ascii=False, indent=2)

                with open(step_results_path, "w", encoding="utf-8") as f:
                    json.dump(step_results, f, ensure_ascii=False, indent=2)

                pbar.update(1)


if __name__ == "__main__":
    main()